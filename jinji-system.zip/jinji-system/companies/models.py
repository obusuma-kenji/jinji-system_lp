from django.db import models


class Company(models.Model):
    """会社・法人情報"""
    name = models.CharField("会社名", max_length=200)
    corporate_number = models.CharField("法人番号", max_length=13, blank=True)
    industry = models.CharField(
        "業種", max_length=50, blank=True,
        help_text="例: 製造業、IT、小売、介護、建設 等"
    )
    address = models.CharField("所在地", max_length=500)
    phone = models.CharField("電話番号", max_length=20, blank=True)
    employee_count = models.IntegerField("従業員数", default=0)
    established_date = models.DateField("設立日", null=True, blank=True)
    fiscal_year_start = models.IntegerField(
        "決算月", default=3, help_text="決算月（1～12）"
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "会社"
        verbose_name_plural = "会社"


class Department(models.Model):
    """部門・部署"""
    company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name='departments')
    name = models.CharField("部門名", max_length=100)
    code = models.CharField("部門コード", max_length=20, blank=True)
    parent = models.ForeignKey(
        'self', on_delete=models.SET_NULL, null=True, blank=True,
        related_name='children', verbose_name="上位部門"
    )
    manager_name = models.CharField("部門長", max_length=100, blank=True)
    description = models.TextField("部門概要", blank=True)
    sort_order = models.IntegerField("表示順", default=0)
    is_active = models.BooleanField("有効", default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        if self.parent:
            return f"{self.parent.name} > {self.name}"
        return self.name

    class Meta:
        verbose_name = "部門"
        verbose_name_plural = "部門"
        ordering = ['company', 'sort_order', 'name']
