from django.contrib import admin
from .models import Company, Department

@admin.register(Company)
class CompanyAdmin(admin.ModelAdmin):
    list_display = ['name', 'industry', 'address', 'employee_count']
    search_fields = ['name', 'corporate_number']

@admin.register(Department)
class DepartmentAdmin(admin.ModelAdmin):
    list_display = ['name', 'code', 'company', 'parent', 'manager_name', 'is_active']
    list_filter = ['company', 'is_active']
    search_fields = ['name', 'code']
