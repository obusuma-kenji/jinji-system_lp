from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('hr_core.urls')),
]

admin.site.site_header = "人事管理システム"
admin.site.site_title = "HR Admin"
admin.site.index_title = "管理メニュー"
