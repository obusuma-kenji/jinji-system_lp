#!/usr/bin/env python
"""汎用人事システム サンプルデータ投入"""
import os, sys, django
from datetime import date, timedelta

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'jinji_config.settings')
django.setup()

from companies.models import Company, Department
from hr_core.models import (
    JobCategory, Position, WageTable, SalaryIncreaseSystem,
    Employee, EvaluationPeriod, EvaluationCriteria, Evaluation, EvaluationScore,
    Goal, PromotionRecord, TrainingPlan,
)

def run():
    print("=" * 50)
    print("汎用人事システム サンプルデータ投入")
    print("=" * 50)

    # 会社
    co, _ = Company.objects.get_or_create(
        name='株式会社テクノフューチャー', defaults={
            'industry': 'IT・ソフトウェア', 'address': '埼玉県さいたま市大宮区桜木町1-1-1',
            'phone': '048-600-0001', 'employee_count': 45, 'fiscal_year_start': 3,
        }
    )
    print(f"✓ 会社: {co.name}")

    # 部門
    dept_data = [
        ('経営企画部', 'D01', None, '代表取締役 山田太郎'),
        ('営業部', 'D02', None, '部長 佐藤花子'),
        ('開発部', 'D03', None, '部長 鈴木一郎'),
        ('管理部', 'D04', None, '部長 田中美咲'),
    ]
    depts = {}
    for name, code, parent, mgr in dept_data:
        d, _ = Department.objects.get_or_create(
            company=co, code=code, defaults={'name': name, 'manager_name': mgr}
        )
        depts[code] = d
    print(f"✓ 部門: {len(depts)}部門")

    # 職種
    cats_data = [('ENG', '技術職'), ('SALES', '営業職'), ('ADMIN', '管理職'), ('GEN', '総合職')]
    cats = {}
    for code, name in cats_data:
        c, _ = JobCategory.objects.get_or_create(company=co, code=code, defaults={'name': name})
        cats[code] = c

    # 職位
    grades = [
        ('GEN', '一般社員', 1, 0), ('GEN', '主任', 2, 36),
        ('GEN', '係長', 3, 60), ('GEN', '課長', 4, 96), ('GEN', '部長', 5, 144),
    ]
    positions = {}
    for cat_code, name, grade, exp in grades:
        p, _ = Position.objects.get_or_create(
            company=co, job_category=cats[cat_code], grade=grade,
            defaults={'name': name, 'required_experience_months': exp}
        )
        positions[grade] = p
        # 賃金テーブル
        WageTable.objects.get_or_create(position=p, defaults={
            'base_salary_start': 200000 + (grade - 1) * 40000,
            'step_raise_amount': 1500 + grade * 500,
            'max_steps': 30,
            'qualification_allowance': grade * 3000,
            'position_allowance': max(0, (grade - 2) * 15000),
        })
    print(f"✓ 職位: {len(positions)}等級")

    # 昇給制度
    SalaryIncreaseSystem.objects.get_or_create(company=co, defaults={
        'has_regular_increase': True, 'increase_timing': 'APRIL',
        'increase_amount_per_step': 1500, 'max_steps_per_year': 4,
        'evaluation_affects_raise': True,
        'evaluation_criteria': 'S評価: 4号昇給, A評価: 3号昇給, B評価: 2号昇給, C評価: 1号昇給',
    })

    # 社員
    emp_data = [
        ('E001', '山田', '太郎', 'D01', 5, 'executive', date(2010, 4, 1), 450000),
        ('E002', '佐藤', '花子', 'D02', 4, 'full_time', date(2012, 4, 1), 380000),
        ('E003', '鈴木', '一郎', 'D03', 4, 'full_time', date(2013, 7, 1), 370000),
        ('E004', '田中', '美咲', 'D04', 3, 'full_time', date(2015, 4, 1), 320000),
        ('E005', '高橋', '健太', 'D03', 2, 'full_time', date(2018, 4, 1), 280000),
        ('E006', '伊藤', '由美', 'D02', 2, 'full_time', date(2019, 10, 1), 270000),
        ('E007', '渡辺', '大輔', 'D03', 1, 'full_time', date(2021, 4, 1), 230000),
        ('E008', '中村', 'さくら', 'D04', 1, 'full_time', date(2022, 4, 1), 220000),
        ('E009', '小林', '翔', 'D03', 1, 'full_time', date(2023, 4, 1), 210000),
        ('E010', '加藤', '真理', 'D02', 1, 'part_time', date(2023, 10, 1), 180000),
    ]
    emps = {}
    for eid, ln, fn, dept_code, grade, etype, hdate, sal in emp_data:
        e, _ = Employee.objects.get_or_create(
            company=co, employee_id=eid, defaults={
                'last_name': ln, 'first_name': fn, 'department': depts[dept_code],
                'current_position': positions[grade], 'employment_type': etype,
                'hire_date': hdate, 'current_base_salary': sal,
                'current_total_salary': int(sal * 1.2),
            }
        )
        emps[eid] = e
    print(f"✓ 社員: {len(emps)}名")

    # 評価期間
    period, _ = EvaluationPeriod.objects.get_or_create(
        company=co, name='2025年度下期', defaults={
            'cycle': 'semi_annual', 'start_date': date(2025, 10, 1),
            'end_date': date(2026, 3, 31), 'is_active': True,
        }
    )
    period2, _ = EvaluationPeriod.objects.get_or_create(
        company=co, name='2026年度上期', defaults={
            'cycle': 'semi_annual', 'start_date': date(2026, 4, 1),
            'end_date': date(2026, 9, 30), 'is_active': True,
        }
    )

    # 評価項目（全職種共通）
    criteria_data = [
        ('業務遂行力', '担当業務の質と量、期限遵守', 1.5, 5),
        ('チームワーク', '協調性、後輩指導、情報共有', 1.0, 5),
        ('課題解決力', '問題発見、改善提案、実行力', 1.2, 5),
        ('自己成長', '学習意欲、資格取得、スキルアップ', 0.8, 5),
        ('コンプライアンス', '規則遵守、情報セキュリティ', 0.5, 5),
    ]
    criteria_objs = []
    for i, (name, desc, weight, mx) in enumerate(criteria_data):
        c, _ = EvaluationCriteria.objects.get_or_create(
            company=co, name=name, defaults={
                'description': desc, 'weight': weight, 'max_score': mx, 'sort_order': i,
            }
        )
        criteria_objs.append(c)

    # 評価データ
    import random
    random.seed(42)
    for eid in ['E002', 'E003', 'E004', 'E005', 'E006', 'E007', 'E008']:
        overall = round(random.uniform(2.5, 4.8), 1)
        ev, created = Evaluation.objects.get_or_create(
            employee=emps[eid], period=period, defaults={
                'evaluator_name': '山田 太郎', 'overall_score': overall,
                'status': 'approved', 'evaluated_at': date(2026, 3, 25),
            }
        )
        if created:
            for crit in criteria_objs:
                EvaluationScore.objects.create(
                    evaluation=ev, criteria=crit, score=random.randint(2, 5)
                )

    print(f"✓ 評価データ投入完了")

    # 目標
    goals_data = [
        ('E005', '新規顧客向けAPI設計・開発', 'マイクロサービスアーキテクチャでAPI基盤を構築', 40, 75, 'active'),
        ('E005', 'AWS認定ソリューションアーキテクト取得', '12月までに合格', 30, 50, 'active'),
        ('E006', '営業売上目標達成', '下期売上2,000万円達成', 50, 85, 'active'),
        ('E007', 'Pythonスキル習得', 'Django開発で独力実装可能レベル', 30, 60, 'active'),
    ]
    for eid, title, desc, weight, rate, status in goals_data:
        Goal.objects.get_or_create(
            employee=emps[eid], period=period2, title=title, defaults={
                'description': desc, 'weight': weight, 'achievement_rate': rate, 'status': status,
            }
        )
    print(f"✓ 目標データ投入完了")

    # 研修
    training_data = [
        (2026, '新入社員研修', 'off_jt', True, date(2026, 4, 7)),
        (2026, 'マネジメント研修', 'external', False, date(2026, 6, 15)),
        (2026, '情報セキュリティ研修', 'online', True, date(2026, 5, 1)),
        (2026, 'コンプライアンス研修', 'online', True, date(2026, 7, 1)),
    ]
    for fy, name, ttype, mandatory, sdate in training_data:
        TrainingPlan.objects.get_or_create(
            company=co, fiscal_year=fy, name=name, defaults={
                'description': f'{name}の実施', 'objectives': f'{name}の目標達成',
                'training_type': ttype, 'is_mandatory': mandatory,
                'scheduled_date': sdate, 'duration_hours': 8,
            }
        )
    print(f"✓ 研修データ投入完了")

    print()
    print("=" * 50)
    print("✅ サンプルデータ投入完了！")
    print(f"  会社: {co.name}")
    print(f"  社員数: {Employee.objects.filter(company=co).count()}名")
    print(f"  トップ: http://127.0.0.1:8000/")
    print(f"  管理: http://127.0.0.1:8000/admin/")
    print("=" * 50)

if __name__ == '__main__':
    run()
