from django.urls import path
from . import views

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    # 社員管理
    path('company/<int:company_id>/employees/', views.employee_list, name='employee_list'),
    path('employee/<int:pk>/', views.employee_detail, name='employee_detail'),
    # 賃金テーブル
    path('company/<int:company_id>/wage-tables/', views.wage_table_list, name='wage_table_list'),
    path('company/<int:company_id>/wage-matrix/', views.wage_step_matrix, name='wage_step_matrix'),
    path('company/<int:company_id>/allowances/', views.allowance_list, name='allowance_list'),
    path('company/<int:company_id>/salary-sim/', views.salary_simulation, name='salary_simulation'),
    # 人事評価
    path('company/<int:company_id>/evaluations/', views.evaluation_list, name='evaluation_list'),
    path('evaluation/<int:pk>/', views.evaluation_detail, name='evaluation_detail'),
    # 目標管理
    path('company/<int:company_id>/goals/', views.goal_list, name='goal_list'),
    path('company/<int:company_id>/goals/new/', views.goal_create, name='goal_create'),
    path('goal/<int:pk>/', views.goal_detail, name='goal_detail'),
    path('goal/<int:pk>/edit/', views.goal_edit, name='goal_edit'),
    path('goal/<int:goal_id>/progress/new/', views.goal_progress_create, name='goal_progress_create'),
    path('company/<int:company_id>/goal-progress/', views.goal_progress_dashboard, name='goal_progress_dashboard'),
    # 1on1
    path('company/<int:company_id>/one-on-one/', views.one_on_one_list, name='one_on_one_list'),
    path('company/<int:company_id>/one-on-one/new/', views.one_on_one_create, name='one_on_one_create'),
    # 等級制度・職務記述・コンピテンシー
    path('company/<int:company_id>/grade-framework/', views.grade_framework, name='grade_framework'),
    path('grade/<int:pk>/', views.grade_detail, name='grade_detail'),
    path('company/<int:company_id>/competencies/', views.competency_list, name='competency_list'),
    path('company/<int:company_id>/competency-setup/', views.competency_setup, name='competency_setup'),
    # 組織図
    path('company/<int:company_id>/org-chart/', views.org_chart, name='org_chart'),
    # 昇給・昇格連動
    path('company/<int:company_id>/raise-rules/', views.raise_promotion_rules, name='raise_promotion_rules'),
    path('company/<int:company_id>/generate-proposals/', views.generate_proposals, name='generate_proposals'),
    path('company/<int:company_id>/proposals/', views.proposal_list, name='proposal_list'),
    path('proposal/<int:pk>/approve/', views.proposal_approve, name='proposal_approve'),
]
