from django.contrib import admin
from .models import (
    JobCategory, Position, WageTable, SalaryIncreaseSystem,
    Employee, EvaluationPeriod, EvaluationCriteria, Evaluation, EvaluationScore,
    Goal, GoalProgress, OneOnOneRecord, PromotionRecord, TrainingPlan, TrainingRecord,
    RaisePromotionRule, RaisePromotionProposal,
    AllowanceType, EmployeeAllowance,
    JobDescription, CompetencyMaster, CompetencyLevelDef,
)

@admin.register(JobCategory)
class JobCategoryAdmin(admin.ModelAdmin):
    list_display = ['code', 'name', 'company']
    list_filter = ['company']

class JobDescriptionInline(admin.StackedInline):
    model = JobDescription
    extra = 0

class CompetencyLevelInline(admin.TabularInline):
    model = CompetencyLevelDef
    extra = 0
    fields = ['competency', 'expected_level', 'expected_behaviors', 'evaluation_criteria']

@admin.register(Position)
class PositionAdmin(admin.ModelAdmin):
    list_display = ['name', 'grade', 'job_category', 'company', 'role_scope', 'min_stay_years']
    list_filter = ['company', 'job_category', 'grade', 'role_scope']
    ordering = ['company', 'job_category', 'grade']
    inlines = [JobDescriptionInline, CompetencyLevelInline]
    fieldsets = (
        ('基本情報', {'fields': ('company', 'department', 'job_category', 'name', 'grade')}),
        ('等級定義', {'fields': (
            'role_summary', 'role_scope', 'authority_level', 'expected_output',
            'leadership_requirement', 'min_stay_years', 'max_stay_years',
            'promotion_criteria', 'required_experience_months', 'required_qualifications',
        )}),
        ('職務概要', {'fields': ('job_description', 'responsibilities')}),
    )

@admin.register(JobDescription)
class JobDescriptionAdmin(admin.ModelAdmin):
    list_display = ['position', 'revision_date', 'revised_by']
    list_filter = ['position__company', 'position__job_category']

@admin.register(CompetencyMaster)
class CompetencyMasterAdmin(admin.ModelAdmin):
    list_display = ['name', 'category', 'company', 'job_category', 'sort_order', 'is_active']
    list_filter = ['company', 'category', 'is_active']

@admin.register(CompetencyLevelDef)
class CompetencyLevelDefAdmin(admin.ModelAdmin):
    list_display = ['competency', 'position', 'expected_level']
    list_filter = ['position__company', 'competency__category', 'expected_level']

@admin.register(WageTable)
class WageTableAdmin(admin.ModelAdmin):
    list_display = ['position', 'base_salary_start', 'step_raise_amount', 'max_steps']
    list_filter = ['position__company']

@admin.register(SalaryIncreaseSystem)
class SalaryIncreaseSystemAdmin(admin.ModelAdmin):
    list_display = ['company', 'has_regular_increase', 'increase_timing', 'increase_amount_per_step']

class EmployeeAllowanceInline(admin.TabularInline):
    model = EmployeeAllowance
    extra = 0
    fields = ['allowance_type', 'amount', 'note', 'start_date', 'end_date', 'is_active']

@admin.register(Employee)
class EmployeeAdmin(admin.ModelAdmin):
    list_display = ['employee_id', 'full_name', 'company', 'department', 'current_position', 'employment_type', 'is_active']
    list_filter = ['company', 'department', 'employment_type', 'is_active']
    search_fields = ['employee_id', 'last_name', 'first_name']
    inlines = [EmployeeAllowanceInline]

    def full_name(self, obj):
        return obj.full_name
    full_name.short_description = '氏名'

@admin.register(AllowanceType)
class AllowanceTypeAdmin(admin.ModelAdmin):
    list_display = ['name', 'category', 'calc_method', 'default_amount', 'taxable', 'is_active', 'company']
    list_filter = ['company', 'category', 'calc_method', 'is_active']

@admin.register(EmployeeAllowance)
class EmployeeAllowanceAdmin(admin.ModelAdmin):
    list_display = ['employee', 'allowance_type', 'amount', 'start_date', 'end_date', 'is_active']
    list_filter = ['allowance_type', 'is_active']
    search_fields = ['employee__last_name', 'employee__first_name']

@admin.register(EvaluationPeriod)
class EvaluationPeriodAdmin(admin.ModelAdmin):
    list_display = ['name', 'company', 'cycle', 'start_date', 'end_date', 'is_active']
    list_filter = ['company', 'cycle', 'is_active']

@admin.register(EvaluationCriteria)
class EvaluationCriteriaAdmin(admin.ModelAdmin):
    list_display = ['name', 'company', 'job_category', 'weight', 'max_score']
    list_filter = ['company', 'job_category']

class EvaluationScoreInline(admin.TabularInline):
    model = EvaluationScore
    extra = 0

@admin.register(Evaluation)
class EvaluationAdmin(admin.ModelAdmin):
    list_display = ['employee', 'period', 'overall_score', 'status', 'evaluator_name']
    list_filter = ['status', 'period']
    inlines = [EvaluationScoreInline]

class GoalProgressInline(admin.TabularInline):
    model = GoalProgress
    extra = 0
    fields = ['recorded_date', 'progress_rate', 'progress_status', 'comment', 'action_items', 'blocker']

@admin.register(Goal)
class GoalAdmin(admin.ModelAdmin):
    list_display = ['employee', 'title', 'category', 'period', 'weight', 'achievement_rate', 'status', 'priority']
    list_filter = ['status', 'category', 'period', 'priority']
    search_fields = ['title', 'employee__last_name', 'employee__first_name']
    inlines = [GoalProgressInline]

@admin.register(GoalProgress)
class GoalProgressAdmin(admin.ModelAdmin):
    list_display = ['goal', 'recorded_date', 'progress_rate', 'progress_status', 'recorded_by']
    list_filter = ['progress_status', 'recorded_date']
    date_hierarchy = 'recorded_date'

@admin.register(OneOnOneRecord)
class OneOnOneRecordAdmin(admin.ModelAdmin):
    list_display = ['employee', 'meeting_date', 'manager_name', 'duration_minutes', 'employee_mood']
    list_filter = ['employee_mood', 'meeting_date', 'manager_name']
    search_fields = ['employee__last_name', 'employee__first_name', 'topics_discussed']
    date_hierarchy = 'meeting_date'

@admin.register(PromotionRecord)
class PromotionRecordAdmin(admin.ModelAdmin):
    list_display = ['employee', 'effective_date', 'record_type', 'from_position', 'to_position']
    list_filter = ['record_type']

class TrainingRecordInline(admin.TabularInline):
    model = TrainingRecord
    extra = 0

@admin.register(TrainingPlan)
class TrainingPlanAdmin(admin.ModelAdmin):
    list_display = ['name', 'fiscal_year', 'training_type', 'scheduled_date', 'is_mandatory', 'company']
    list_filter = ['fiscal_year', 'training_type', 'company']
    filter_horizontal = ['target_positions', 'target_departments']
    inlines = [TrainingRecordInline]

@admin.register(TrainingRecord)
class TrainingRecordAdmin(admin.ModelAdmin):
    list_display = ['training_plan', 'actual_date']
    filter_horizontal = ['participants']

@admin.register(RaisePromotionRule)
class RaisePromotionRuleAdmin(admin.ModelAdmin):
    list_display = ['company', 'eval_rank', 'score_min', 'score_max', 'raise_steps', 'promotion_eligible', 'bonus_multiplier']
    list_filter = ['company', 'eval_rank']

@admin.register(RaisePromotionProposal)
class RaisePromotionProposalAdmin(admin.ModelAdmin):
    list_display = ['employee', 'eval_rank', 'raise_steps', 'raise_amount', 'new_salary', 'is_promotion_candidate', 'status']
    list_filter = ['status', 'eval_rank']
    search_fields = ['employee__last_name', 'employee__first_name']
