from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
from companies.models import Company, Department


# ================================================================
# 職種・職位
# ================================================================

class JobCategory(models.Model):
    """職種マスタ（業種フリー・会社ごとにカスタマイズ可）"""
    company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name='job_categories')
    code = models.CharField("職種コード", max_length=20)
    name = models.CharField("職種名", max_length=50)
    description = models.TextField("職種説明", blank=True)
    sort_order = models.IntegerField("表示順", default=0)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "職種"
        verbose_name_plural = "職種"
        unique_together = ['company', 'code']
        ordering = ['sort_order', 'code']


class Position(models.Model):
    """職位（等級）階層定義"""
    company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name='positions')
    department = models.ForeignKey(
        Department, on_delete=models.SET_NULL, null=True, blank=True, related_name='positions'
    )
    job_category = models.ForeignKey(JobCategory, on_delete=models.CASCADE)
    name = models.CharField("職位名", max_length=50, help_text="例: 一般社員、主任、課長、部長")
    grade = models.IntegerField(
        "等級", validators=[MinValueValidator(1), MaxValueValidator(20)],
        help_text="数値が大きいほど上位"
    )
    # --- 等級定義 ---
    ROLE_SCOPE_CHOICES = [
        ('self', '自己完結'), ('team', 'チーム内'),
        ('dept', '部門横断'), ('company', '全社'),
    ]
    role_summary = models.TextField("等級の役割定義", blank=True,
        help_text="この等級に求められる役割の概要")
    role_scope = models.CharField("影響範囲", max_length=20,
        choices=ROLE_SCOPE_CHOICES, default='self')
    authority_level = models.TextField("権限レベル", blank=True,
        help_text="決裁権限・承認権限の範囲")
    expected_output = models.TextField("期待成果", blank=True,
        help_text="この等級で求められる成果水準")
    leadership_requirement = models.TextField("リーダーシップ要件", blank=True,
        help_text="マネジメント・リーダーシップに関する要件")
    min_stay_years = models.IntegerField("最低滞留年数", default=1,
        help_text="昇格に必要な最低在籍年数")
    max_stay_years = models.IntegerField("標準滞留年数", default=3,
        help_text="標準的にこの等級に留まる年数")
    promotion_criteria = models.TextField("昇格要件", blank=True,
        help_text="次の等級に上がるために必要な条件")
    required_experience_months = models.IntegerField("必要経験月数", default=0)
    required_qualifications = models.TextField("必要資格・要件", blank=True)
    # --- 職務概要（簡易版。詳細はJobDescriptionで） ---
    job_description = models.TextField("職務内容", blank=True)
    responsibilities = models.TextField("責任範囲", blank=True)

    class Meta:
        unique_together = ['company', 'job_category', 'grade']
        ordering = ['job_category', 'grade']
        verbose_name = "職位"
        verbose_name_plural = "職位"

    def __str__(self):
        return f"{self.job_category.name} - {self.name}（{self.grade}等級）"


class JobDescription(models.Model):
    """職務記述書（ジョブディスクリプション）"""
    position = models.OneToOneField(Position, on_delete=models.CASCADE, related_name='jd')
    purpose = models.TextField("職務の目的",
        help_text="このポジションが存在する理由・ミッション")
    key_responsibilities = models.TextField("主要業務",
        help_text="担当する主な業務内容（重要度順）")
    kpi_metrics = models.TextField("成功指標（KPI）", blank=True,
        help_text="業績を測定する具体的な指標")
    required_knowledge = models.TextField("必要な知識・スキル", blank=True,
        help_text="業務遂行に必要な専門知識・技術スキル")
    required_certifications = models.TextField("必要・推奨資格", blank=True,
        help_text="必須資格と推奨資格")
    education_requirement = models.CharField("学歴要件", max_length=200, blank=True)
    experience_requirement = models.TextField("経験要件", blank=True,
        help_text="必要な実務経験の内容と年数")
    working_conditions = models.TextField("勤務条件", blank=True,
        help_text="勤務時間・出張・リモート勤務など")
    internal_relations = models.TextField("社内関係", blank=True,
        help_text="報告先・連携部署・管理する人数など")
    external_relations = models.TextField("社外関係", blank=True,
        help_text="顧客・取引先・行政機関との関わり")
    career_path = models.TextField("キャリアパス", blank=True,
        help_text="この職位からの典型的なキャリア展開")
    revision_date = models.DateField("最終改定日", null=True, blank=True)
    revised_by = models.CharField("改定者", max_length=100, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"JD: {self.position.name}"

    class Meta:
        verbose_name = "職務記述書"
        verbose_name_plural = "職務記述書"


class CompetencyMaster(models.Model):
    """コンピテンシー項目マスタ"""
    CATEGORY_CHOICES = [
        ('core', '全社共通コンピテンシー'),
        ('management', 'マネジメントコンピテンシー'),
        ('functional', '職種別コンピテンシー'),
    ]
    company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name='competencies')
    category = models.CharField("分類", max_length=20, choices=CATEGORY_CHOICES, default='core')
    name = models.CharField("コンピテンシー名", max_length=100,
        help_text="例: 課題解決力、コミュニケーション、リーダーシップ")
    definition = models.TextField("定義",
        help_text="このコンピテンシーの意味・概要")
    behavioral_indicators = models.TextField("行動指標（共通）", blank=True,
        help_text="等級を問わない共通的な行動例")
    job_category = models.ForeignKey(
        JobCategory, on_delete=models.SET_NULL, null=True, blank=True,
        help_text="職種別コンピテンシーの場合に紐付け"
    )
    sort_order = models.IntegerField("表示順", default=0)
    is_active = models.BooleanField("有効", default=True)

    def __str__(self):
        return f"{self.name}（{self.get_category_display()}）"

    class Meta:
        verbose_name = "コンピテンシー項目"
        verbose_name_plural = "コンピテンシー項目"
        ordering = ['category', 'sort_order']


class CompetencyLevelDef(models.Model):
    """等級別コンピテンシーレベル定義"""
    LEVEL_CHOICES = [
        (1, 'Lv1 — 基礎（指導のもとで実行）'),
        (2, 'Lv2 — 実践（自律的に実行）'),
        (3, 'Lv3 — 応用（他者を指導）'),
        (4, 'Lv4 — 熟達（組織を牽引）'),
        (5, 'Lv5 — 卓越（変革を推進）'),
    ]
    competency = models.ForeignKey(CompetencyMaster, on_delete=models.CASCADE, related_name='level_defs')
    position = models.ForeignKey(Position, on_delete=models.CASCADE, related_name='competency_levels')
    expected_level = models.IntegerField("期待レベル", choices=LEVEL_CHOICES, default=1)
    expected_behaviors = models.TextField("期待される行動",
        help_text="この等級でこのコンピテンシーに求められる具体的な行動")
    evaluation_criteria = models.TextField("評価基準", blank=True,
        help_text="このレベルに達しているかを判断する基準")
    development_actions = models.TextField("育成アクション", blank=True,
        help_text="このレベルに到達するための育成施策")

    def __str__(self):
        return f"{self.competency.name} × {self.position.name} = Lv{self.expected_level}"

    class Meta:
        verbose_name = "コンピテンシーレベル定義"
        verbose_name_plural = "コンピテンシーレベル定義"
        unique_together = ['competency', 'position']
        ordering = ['position__grade', 'competency__sort_order']


# ================================================================
# 賃金テーブル
# ================================================================

class WageTable(models.Model):
    """号級賃金テーブル"""
    position = models.OneToOneField(Position, on_delete=models.CASCADE, related_name='wage_table')
    base_salary_start = models.PositiveIntegerField("初号給（円）", default=0)
    step_raise_amount = models.PositiveIntegerField("1号あたり昇給額（円）", default=0)
    max_steps = models.PositiveIntegerField("最大号数", default=30)
    qualification_allowance = models.IntegerField("資格手当（円）", default=0)
    position_allowance = models.IntegerField("役職手当（円）", default=0)
    mid_career_start_step = models.PositiveIntegerField(
        "中途入社初期号数", default=1,
        help_text="中途採用者の初期号数（経験に応じて調整）"
    )

    def __str__(self):
        return f"{self.position.name} の賃金テーブル"

    def get_salary_for_step(self, step):
        if step < 1:
            step = 1
        if step > self.max_steps:
            step = self.max_steps
        return self.base_salary_start + (self.step_raise_amount * (step - 1))

    def get_full_table(self):
        """号俸表の全展開（1号〜最大号のリスト）"""
        return [
            {'step': s, 'salary': self.get_salary_for_step(s)}
            for s in range(1, self.max_steps + 1)
        ]

    class Meta:
        verbose_name = "賃金テーブル"
        verbose_name_plural = "賃金テーブル"


class AllowanceType(models.Model):
    """手当種別マスタ"""
    CALC_METHOD_CHOICES = [
        ('fixed', '固定額'),
        ('tier', '段階別'),
        ('percentage', '基本給比率'),
        ('actual', '実費精算'),
    ]
    CATEGORY_CHOICES = [
        ('family', '家族手当'),
        ('housing', '住宅手当'),
        ('commute', '通勤手当'),
        ('qualification', '資格手当'),
        ('position', '役職手当'),
        ('skill', '技能手当'),
        ('overtime_fixed', '固定残業手当'),
        ('region', '地域手当'),
        ('special', '特別手当'),
        ('other', 'その他'),
    ]
    company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name='allowance_types')
    category = models.CharField("手当カテゴリ", max_length=20, choices=CATEGORY_CHOICES)
    name = models.CharField("手当名", max_length=100)
    calc_method = models.CharField("計算方法", max_length=20, choices=CALC_METHOD_CHOICES, default='fixed')
    default_amount = models.IntegerField("デフォルト金額（円）", default=0)
    percentage_rate = models.DecimalField(
        "基本給比率（%）", max_digits=5, decimal_places=2, default=0,
        help_text="計算方法が「基本給比率」の場合に使用"
    )
    max_amount = models.IntegerField("上限額（円）", default=0, help_text="0=上限なし")
    taxable = models.BooleanField("課税対象", default=True)
    description = models.TextField("説明・適用条件", blank=True)
    tier_rules = models.TextField(
        "段階別ルール", blank=True,
        help_text="段階別の場合、JSON形式で定義。例: [{\"label\":\"配偶者\",\"amount\":15000},{\"label\":\"子1人\",\"amount\":5000}]"
    )
    is_active = models.BooleanField("有効", default=True)
    sort_order = models.IntegerField("表示順", default=0)

    def __str__(self):
        return f"{self.name}（{self.get_category_display()}）"

    class Meta:
        verbose_name = "手当種別"
        verbose_name_plural = "手当種別"
        ordering = ['sort_order', 'category']


class EmployeeAllowance(models.Model):
    """社員別手当"""
    employee = models.ForeignKey('Employee', on_delete=models.CASCADE, related_name='allowances')
    allowance_type = models.ForeignKey(AllowanceType, on_delete=models.CASCADE)
    amount = models.IntegerField("支給額（円）", default=0)
    note = models.CharField("備考", max_length=200, blank=True)
    start_date = models.DateField("適用開始日", null=True, blank=True)
    end_date = models.DateField("適用終了日", null=True, blank=True, help_text="空欄=無期限")
    is_active = models.BooleanField("有効", default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    @property
    def is_current(self):
        from datetime import date
        today = date.today()
        if self.start_date and today < self.start_date:
            return False
        if self.end_date and today > self.end_date:
            return False
        return self.is_active

    def __str__(self):
        return f"{self.employee.full_name} - {self.allowance_type.name}（¥{self.amount:,}）"

    class Meta:
        verbose_name = "社員別手当"
        verbose_name_plural = "社員別手当"
        ordering = ['allowance_type__sort_order']


class SalaryIncreaseSystem(models.Model):
    """昇給制度"""
    TIMING_CHOICES = [
        ('APRIL', '4月'), ('JULY', '7月'),
        ('OCTOBER', '10月'), ('JANUARY', '1月'),
    ]
    company = models.OneToOneField(Company, on_delete=models.CASCADE, related_name='salary_system')
    has_regular_increase = models.BooleanField("定期昇給の有無", default=True)
    increase_timing = models.CharField("定期昇給時期", max_length=20, choices=TIMING_CHOICES, default='APRIL')
    increase_amount_per_step = models.IntegerField("1号あたりの昇給額（円）", default=1000)
    max_steps_per_year = models.IntegerField("年間最大昇給号数", default=4)
    has_special_increase = models.BooleanField("特別昇給制度の有無", default=False)
    special_increase_conditions = models.TextField("特別昇給の条件", blank=True)
    evaluation_affects_raise = models.BooleanField("評価が昇給に影響するか", default=True)
    evaluation_criteria = models.TextField("評価と昇給の関係", blank=True)
    notes = models.TextField("備考", blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "昇給制度"
        verbose_name_plural = "昇給制度"

    def __str__(self):
        return f"{self.company.name} - 昇給制度"


# ================================================================
# 社員管理
# ================================================================

class Employee(models.Model):
    """社員情報"""
    EMPLOYMENT_CHOICES = [
        ('full_time', '正社員'), ('contract', '契約社員'),
        ('part_time', 'パート・アルバイト'), ('temp', '派遣社員'),
        ('executive', '役員'),
    ]
    company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name='employees')
    department = models.ForeignKey(
        Department, on_delete=models.SET_NULL, null=True, blank=True, related_name='employees'
    )
    employee_id = models.CharField("社員番号", max_length=20)
    last_name = models.CharField("姓", max_length=50)
    first_name = models.CharField("名", max_length=50)
    last_name_kana = models.CharField("姓（カナ）", max_length=50, blank=True)
    first_name_kana = models.CharField("名（カナ）", max_length=50, blank=True)
    email = models.EmailField("メールアドレス", blank=True)
    employment_type = models.CharField("雇用形態", max_length=20, choices=EMPLOYMENT_CHOICES, default='full_time')
    hire_date = models.DateField("入社日")
    current_position = models.ForeignKey(Position, on_delete=models.SET_NULL, null=True, blank=True)
    current_base_salary = models.IntegerField("現在の基本給（円）", default=0)
    current_total_salary = models.IntegerField("現在の総支給額（円）", default=0)
    qualifications = models.TextField("保有資格", blank=True)
    latest_evaluation_score = models.DecimalField(
        "最新評価スコア", max_digits=3, decimal_places=1, default=0.0
    )
    latest_evaluation_date = models.DateField("最新評価日", null=True, blank=True)
    is_active = models.BooleanField("在籍中", default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    @property
    def full_name(self):
        return f"{self.last_name} {self.first_name}"

    @property
    def experience_months(self):
        from datetime import date
        if self.hire_date:
            today = date.today()
            return (today.year - self.hire_date.year) * 12 + (today.month - self.hire_date.month)
        return 0

    @property
    def experience_years(self):
        return self.experience_months // 12

    @property
    def total_allowances(self):
        """有効な手当の合計額"""
        return sum(a.amount for a in self.allowances.all() if a.is_current)

    @property
    def calculated_total_salary(self):
        """基本給＋手当合計"""
        return self.current_base_salary + self.total_allowances

    def __str__(self):
        return f"{self.full_name}（{self.employee_id}）"

    class Meta:
        verbose_name = "社員"
        verbose_name_plural = "社員"
        unique_together = ['company', 'employee_id']
        ordering = ['company', 'employee_id']


# ================================================================
# 人事評価
# ================================================================

class EvaluationPeriod(models.Model):
    """評価期間マスタ"""
    CYCLE_CHOICES = [
        ('annual', '年次'), ('semi_annual', '半期'), ('quarterly', '四半期'),
    ]
    company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name='eval_periods')
    name = models.CharField("評価期間名", max_length=50, help_text="例: 2026年度上期")
    cycle = models.CharField("評価サイクル", max_length=20, choices=CYCLE_CHOICES, default='semi_annual')
    start_date = models.DateField("開始日")
    end_date = models.DateField("終了日")
    is_active = models.BooleanField("評価受付中", default=False)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "評価期間"
        verbose_name_plural = "評価期間"
        ordering = ['-start_date']


class EvaluationCriteria(models.Model):
    """評価項目"""
    company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name='eval_criteria')
    job_category = models.ForeignKey(
        JobCategory, on_delete=models.CASCADE, null=True, blank=True,
        help_text="空欄の場合は全職種共通"
    )
    name = models.CharField("評価項目名", max_length=100)
    description = models.TextField("評価基準の説明")
    weight = models.DecimalField("ウェイト", max_digits=3, decimal_places=2, default=1.0)
    max_score = models.IntegerField("最高点", default=5)
    sort_order = models.IntegerField("表示順", default=0)

    def __str__(self):
        scope = self.job_category.name if self.job_category else "全職種共通"
        return f"[{scope}] {self.name}"

    class Meta:
        verbose_name = "評価項目"
        verbose_name_plural = "評価項目"
        ordering = ['sort_order']


class Evaluation(models.Model):
    """人事評価"""
    STATUS_CHOICES = [
        ('draft', '下書き'), ('submitted', '提出済'), ('approved', '確定'),
    ]
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name='evaluations')
    period = models.ForeignKey(EvaluationPeriod, on_delete=models.CASCADE)
    evaluator_name = models.CharField("評価者", max_length=100)
    overall_score = models.DecimalField("総合評価", max_digits=3, decimal_places=1, default=0.0)
    overall_comment = models.TextField("総合コメント", blank=True)
    self_comment = models.TextField("本人コメント", blank=True)
    status = models.CharField("ステータス", max_length=20, choices=STATUS_CHOICES, default='draft')
    evaluated_at = models.DateField("評価日", null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.employee.full_name} - {self.period.name}"

    class Meta:
        verbose_name = "人事評価"
        verbose_name_plural = "人事評価"
        unique_together = ['employee', 'period']


class EvaluationScore(models.Model):
    """評価項目ごとのスコア"""
    evaluation = models.ForeignKey(Evaluation, on_delete=models.CASCADE, related_name='scores')
    criteria = models.ForeignKey(EvaluationCriteria, on_delete=models.CASCADE)
    score = models.IntegerField("スコア", default=0)
    comment = models.TextField("コメント", blank=True)

    class Meta:
        verbose_name = "評価スコア"
        verbose_name_plural = "評価スコア"
        unique_together = ['evaluation', 'criteria']


# ================================================================
# 目標管理（MBO）
# ================================================================

class Goal(models.Model):
    """目標"""
    PRIORITY_CHOICES = [('high', '高'), ('medium', '中'), ('low', '低')]
    STATUS_CHOICES = [
        ('draft', '設定中'), ('active', '実行中'),
        ('completed', '達成'), ('cancelled', '中止'),
    ]
    CATEGORY_CHOICES = [
        ('performance', '業績目標'),
        ('competency', '能力開発目標'),
        ('behavior', '行動目標'),
    ]
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name='goals')
    period = models.ForeignKey(EvaluationPeriod, on_delete=models.CASCADE)
    parent_goal = models.ForeignKey(
        'self', on_delete=models.SET_NULL, null=True, blank=True,
        related_name='child_goals', verbose_name="上位目標",
        help_text="組織目標やチーム目標を親として紐付け"
    )
    category = models.CharField(
        "目標カテゴリ", max_length=20, choices=CATEGORY_CHOICES, default='performance'
    )
    title = models.CharField("目標タイトル", max_length=200)
    description = models.TextField("目標内容・達成基準")
    weight = models.IntegerField("ウェイト（%）", default=20, validators=[MinValueValidator(0), MaxValueValidator(100)])
    priority = models.CharField("優先度", max_length=10, choices=PRIORITY_CHOICES, default='medium')
    target_value = models.CharField("目標値", max_length=100, blank=True, help_text="例: 売上1000万円、資格取得")
    actual_value = models.CharField("実績値", max_length=100, blank=True)
    achievement_rate = models.IntegerField("達成率（%）", default=0)
    status = models.CharField("ステータス", max_length=20, choices=STATUS_CHOICES, default='draft')
    due_date = models.DateField("期限日", null=True, blank=True)
    self_review = models.TextField("本人振り返り", blank=True)
    manager_review = models.TextField("上司コメント", blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    @property
    def latest_progress(self):
        return self.progress_logs.order_by('-recorded_date').first()

    @property
    def progress_count(self):
        return self.progress_logs.count()

    def __str__(self):
        return f"{self.employee.full_name} - {self.title}"

    class Meta:
        verbose_name = "目標"
        verbose_name_plural = "目標"
        ordering = ['-period__start_date', 'employee']


class GoalProgress(models.Model):
    """目標の中間進捗（チェックイン）"""
    PROGRESS_STATUS_CHOICES = [
        ('on_track', '順調'),
        ('at_risk', '要注意'),
        ('behind', '遅延'),
        ('ahead', '前倒し'),
    ]
    goal = models.ForeignKey(Goal, on_delete=models.CASCADE, related_name='progress_logs')
    recorded_date = models.DateField("記録日")
    progress_rate = models.IntegerField(
        "進捗率（%）", default=0,
        validators=[MinValueValidator(0), MaxValueValidator(100)]
    )
    progress_status = models.CharField(
        "進捗ステータス", max_length=20, choices=PROGRESS_STATUS_CHOICES, default='on_track'
    )
    comment = models.TextField("進捗コメント")
    action_items = models.TextField("次のアクション", blank=True)
    blocker = models.TextField("障害・課題", blank=True)
    recorded_by = models.CharField("記録者", max_length=100, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.goal.title} - {self.recorded_date} ({self.progress_rate}%)"

    class Meta:
        verbose_name = "目標進捗"
        verbose_name_plural = "目標進捗"
        ordering = ['-recorded_date']


class OneOnOneRecord(models.Model):
    """1on1面談記録"""
    MOOD_CHOICES = [
        ('great', '好調'), ('good', '良好'), ('neutral', '普通'),
        ('concerned', '懸念あり'), ('struggling', '苦戦中'),
    ]
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name='one_on_one_records')
    meeting_date = models.DateField("面談日")
    manager_name = models.CharField("面談者（上司）", max_length=100)
    duration_minutes = models.IntegerField("面談時間（分）", default=30)
    employee_mood = models.CharField(
        "本人の状態", max_length=20, choices=MOOD_CHOICES, default='neutral'
    )
    topics_discussed = models.TextField("話した内容")
    goal_progress_notes = models.TextField("目標に関するメモ", blank=True)
    action_items = models.TextField("次回までのアクション", blank=True)
    support_needed = models.TextField("必要なサポート", blank=True)
    private_note = models.TextField("管理者メモ（非公開）", blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.employee.full_name} - 1on1 ({self.meeting_date})"

    class Meta:
        verbose_name = "1on1面談記録"
        verbose_name_plural = "1on1面談記録"
        ordering = ['-meeting_date']


# ================================================================
# 昇給・昇格ルール＆自動連動
# ================================================================

class RaisePromotionRule(models.Model):
    """評価ランクに基づく昇給・昇格ルール"""
    EVAL_RANK_CHOICES = [
        ('S', 'S（卓越）'), ('A', 'A（優秀）'), ('B', 'B（標準）'),
        ('C', 'C（努力要）'), ('D', 'D（不十分）'),
    ]
    company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name='raise_promotion_rules')
    eval_rank = models.CharField("評価ランク", max_length=2, choices=EVAL_RANK_CHOICES)
    score_min = models.DecimalField("スコア下限", max_digits=3, decimal_places=1, help_text="この評価ランクに該当する最小スコア")
    score_max = models.DecimalField("スコア上限", max_digits=3, decimal_places=1, help_text="この評価ランクに該当する最大スコア")
    raise_steps = models.IntegerField("昇給号数", default=0, help_text="この評価ランクで昇給する号数")
    promotion_eligible = models.BooleanField("昇格候補", default=False, help_text="この評価ランクで昇格候補になるか")
    bonus_multiplier = models.DecimalField(
        "賞与倍率", max_digits=3, decimal_places=2, default=1.0,
        help_text="基準賞与に対する倍率（1.0=標準）"
    )
    description = models.TextField("説明", blank=True)

    def __str__(self):
        return f"{self.company.name} - {self.eval_rank}ランク（{self.score_min}〜{self.score_max}）"

    class Meta:
        verbose_name = "昇給・昇格ルール"
        verbose_name_plural = "昇給・昇格ルール"
        unique_together = ['company', 'eval_rank']
        ordering = ['-score_min']


class RaisePromotionProposal(models.Model):
    """昇給・昇格提案（評価確定後に自動生成）"""
    STATUS_CHOICES = [
        ('pending', '承認待ち'), ('approved', '承認済'),
        ('rejected', '却下'), ('applied', '適用済'),
    ]
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name='raise_proposals')
    evaluation = models.ForeignKey(Evaluation, on_delete=models.CASCADE, related_name='raise_proposals')
    rule = models.ForeignKey(RaisePromotionRule, on_delete=models.SET_NULL, null=True, blank=True)
    eval_rank = models.CharField("評価ランク", max_length=2, choices=RaisePromotionRule.EVAL_RANK_CHOICES)
    # 昇給情報
    current_salary = models.IntegerField("現在の基本給（円）", default=0)
    raise_steps = models.IntegerField("昇給号数", default=0)
    raise_amount = models.IntegerField("昇給額（円）", default=0)
    new_salary = models.IntegerField("昇給後基本給（円）", default=0)
    # 昇格情報
    is_promotion_candidate = models.BooleanField("昇格候補", default=False)
    current_position = models.ForeignKey(
        Position, on_delete=models.SET_NULL, null=True, blank=True, related_name='+'
    )
    proposed_position = models.ForeignKey(
        Position, on_delete=models.SET_NULL, null=True, blank=True, related_name='+',
        verbose_name="昇格先"
    )
    # 賞与情報
    bonus_multiplier = models.DecimalField("賞与倍率", max_digits=3, decimal_places=2, default=1.0)
    # ステータス
    status = models.CharField("ステータス", max_length=20, choices=STATUS_CHOICES, default='pending')
    approved_by = models.CharField("承認者", max_length=100, blank=True)
    approved_at = models.DateTimeField("承認日時", null=True, blank=True)
    effective_date = models.DateField("適用日", null=True, blank=True)
    notes = models.TextField("備考", blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def apply_to_employee(self):
        """承認済みの提案を社員マスタに反映"""
        emp = self.employee
        # 昇給反映
        if self.raise_amount > 0:
            emp.current_base_salary = self.new_salary
            emp.current_total_salary = self.new_salary  # 手当は別途計算
        # 昇格反映
        if self.proposed_position and self.is_promotion_candidate:
            old_position = emp.current_position
            emp.current_position = self.proposed_position
            # PromotionRecordを自動生成
            PromotionRecord.objects.create(
                employee=emp,
                effective_date=self.effective_date or __import__('datetime').date.today(),
                record_type='promotion',
                from_position=old_position,
                to_position=self.proposed_position,
                from_department=emp.department,
                to_department=emp.department,
                salary_before=self.current_salary,
                salary_after=self.new_salary,
                reason=f"評価ランク{self.eval_rank}に基づく昇格",
                approved_by=self.approved_by,
            )
        # 評価スコア反映
        emp.latest_evaluation_score = self.evaluation.overall_score
        emp.latest_evaluation_date = self.evaluation.evaluated_at
        emp.save()
        self.status = 'applied'
        self.save()

    def __str__(self):
        return f"{self.employee.full_name} - {self.eval_rank}ランク（{self.get_status_display()}）"

    class Meta:
        verbose_name = "昇給・昇格提案"
        verbose_name_plural = "昇給・昇格提案"
        unique_together = ['employee', 'evaluation']
        ordering = ['-created_at']


# ================================================================
# 昇格・異動記録
# ================================================================

class PromotionRecord(models.Model):
    """昇格・異動記録"""
    TYPE_CHOICES = [
        ('promotion', '昇格'), ('demotion', '降格'),
        ('transfer', '異動'), ('lateral', '配置転換'),
    ]
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name='promotions')
    effective_date = models.DateField("発令日")
    record_type = models.CharField("種別", max_length=20, choices=TYPE_CHOICES)
    from_position = models.ForeignKey(Position, on_delete=models.SET_NULL, null=True, related_name='+')
    to_position = models.ForeignKey(Position, on_delete=models.CASCADE, related_name='+')
    from_department = models.ForeignKey(Department, on_delete=models.SET_NULL, null=True, blank=True, related_name='+')
    to_department = models.ForeignKey(Department, on_delete=models.SET_NULL, null=True, blank=True, related_name='+')
    salary_before = models.IntegerField("変更前給与（円）", default=0)
    salary_after = models.IntegerField("変更後給与（円）", default=0)
    reason = models.TextField("理由", blank=True)
    approved_by = models.CharField("承認者", max_length=100, blank=True)

    def __str__(self):
        return f"{self.employee.full_name} - {self.get_record_type_display()}（{self.effective_date}）"

    class Meta:
        verbose_name = "昇格・異動記録"
        verbose_name_plural = "昇格・異動記録"
        ordering = ['-effective_date']


# ================================================================
# 研修管理
# ================================================================

class TrainingPlan(models.Model):
    """研修計画"""
    TYPE_CHOICES = [
        ('ojt', 'OJT'), ('off_jt', 'Off-JT'),
        ('external', '外部研修'), ('online', 'オンライン研修'),
    ]
    company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name='training_plans')
    fiscal_year = models.IntegerField("年度")
    name = models.CharField("研修名", max_length=200)
    target_positions = models.ManyToManyField(Position, verbose_name="対象職位", blank=True)
    target_departments = models.ManyToManyField(Department, verbose_name="対象部門", blank=True)
    description = models.TextField("研修内容")
    objectives = models.TextField("目標・到達目標")
    scheduled_date = models.DateField("実施予定日", null=True, blank=True)
    training_type = models.CharField("研修形態", max_length=20, choices=TYPE_CHOICES)
    duration_hours = models.DecimalField("時間", max_digits=4, decimal_places=1, null=True, blank=True)
    instructor = models.CharField("講師", max_length=200, blank=True)
    is_mandatory = models.BooleanField("必須研修", default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.fiscal_year}年度 - {self.name}"

    class Meta:
        verbose_name = "研修計画"
        verbose_name_plural = "研修計画"
        ordering = ['-fiscal_year', 'scheduled_date']


class TrainingRecord(models.Model):
    """研修実施記録"""
    training_plan = models.ForeignKey(TrainingPlan, on_delete=models.CASCADE, related_name='records')
    actual_date = models.DateField("実施日")
    participants = models.ManyToManyField(Employee, verbose_name="参加者", related_name='training_records')
    content = models.TextField("実施内容")
    evaluation = models.TextField("評価・フィードバック", blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.training_plan.name} - {self.actual_date}"

    class Meta:
        verbose_name = "研修実施記録"
        verbose_name_plural = "研修実施記録"
        ordering = ['-actual_date']
