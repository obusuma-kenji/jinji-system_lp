from django import forms
from .models import Goal, GoalProgress, OneOnOneRecord, Employee, EvaluationPeriod


class GoalForm(forms.ModelForm):
    """目標設定フォーム"""
    class Meta:
        model = Goal
        fields = [
            'employee', 'period', 'parent_goal', 'category',
            'title', 'description', 'weight', 'priority',
            'target_value', 'due_date', 'status',
        ]
        widgets = {
            'employee': forms.Select(attrs={'class': 'form-input'}),
            'period': forms.Select(attrs={'class': 'form-input'}),
            'parent_goal': forms.Select(attrs={'class': 'form-input'}),
            'category': forms.Select(attrs={'class': 'form-input'}),
            'title': forms.TextInput(attrs={'class': 'form-input', 'placeholder': '例: 新規顧客獲得10件'}),
            'description': forms.Textarea(attrs={'class': 'form-input', 'rows': 4, 'placeholder': '達成基準を具体的に記入してください'}),
            'weight': forms.NumberInput(attrs={'class': 'form-input', 'min': 0, 'max': 100}),
            'priority': forms.Select(attrs={'class': 'form-input'}),
            'target_value': forms.TextInput(attrs={'class': 'form-input', 'placeholder': '例: 売上1000万円、資格取得'}),
            'due_date': forms.DateInput(attrs={'class': 'form-input', 'type': 'date'}),
            'status': forms.Select(attrs={'class': 'form-input'}),
        }

    def __init__(self, *args, company=None, **kwargs):
        super().__init__(*args, **kwargs)
        if company:
            self.fields['employee'].queryset = Employee.objects.filter(
                company=company, is_active=True
            ).order_by('last_name')
            self.fields['period'].queryset = EvaluationPeriod.objects.filter(
                company=company
            ).order_by('-start_date')
            self.fields['parent_goal'].queryset = Goal.objects.filter(
                employee__company=company
            ).order_by('-period__start_date', 'title')
            self.fields['parent_goal'].required = False
            self.fields['parent_goal'].empty_label = '（なし — 最上位目標）'


class GoalEditForm(forms.ModelForm):
    """目標の進捗更新フォーム（実績・達成率・振り返り）"""
    class Meta:
        model = Goal
        fields = [
            'actual_value', 'achievement_rate', 'status',
            'self_review', 'manager_review',
        ]
        widgets = {
            'actual_value': forms.TextInput(attrs={'class': 'form-input', 'placeholder': '実績を入力'}),
            'achievement_rate': forms.NumberInput(attrs={'class': 'form-input', 'min': 0, 'max': 200}),
            'status': forms.Select(attrs={'class': 'form-input'}),
            'self_review': forms.Textarea(attrs={'class': 'form-input', 'rows': 3, 'placeholder': '本人振り返りを記入'}),
            'manager_review': forms.Textarea(attrs={'class': 'form-input', 'rows': 3, 'placeholder': '上司コメントを記入'}),
        }


class GoalProgressForm(forms.ModelForm):
    """進捗チェックインフォーム"""
    class Meta:
        model = GoalProgress
        fields = [
            'recorded_date', 'progress_rate', 'progress_status',
            'comment', 'action_items', 'blocker', 'recorded_by',
        ]
        widgets = {
            'recorded_date': forms.DateInput(attrs={'class': 'form-input', 'type': 'date'}),
            'progress_rate': forms.NumberInput(attrs={'class': 'form-input', 'min': 0, 'max': 100}),
            'progress_status': forms.Select(attrs={'class': 'form-input'}),
            'comment': forms.Textarea(attrs={'class': 'form-input', 'rows': 3, 'placeholder': '現在の進捗状況を記入'}),
            'action_items': forms.Textarea(attrs={'class': 'form-input', 'rows': 2, 'placeholder': '次回までに行うアクション'}),
            'blocker': forms.Textarea(attrs={'class': 'form-input', 'rows': 2, 'placeholder': '障害や課題があれば記入'}),
            'recorded_by': forms.TextInput(attrs={'class': 'form-input', 'placeholder': '記録者名'}),
        }


class OneOnOneForm(forms.ModelForm):
    """1on1面談記録フォーム"""
    class Meta:
        model = OneOnOneRecord
        fields = [
            'employee', 'meeting_date', 'manager_name', 'duration_minutes',
            'employee_mood', 'topics_discussed', 'goal_progress_notes',
            'action_items', 'support_needed', 'private_note',
        ]
        widgets = {
            'employee': forms.Select(attrs={'class': 'form-input'}),
            'meeting_date': forms.DateInput(attrs={'class': 'form-input', 'type': 'date'}),
            'manager_name': forms.TextInput(attrs={'class': 'form-input', 'placeholder': '面談者（上司）名'}),
            'duration_minutes': forms.NumberInput(attrs={'class': 'form-input', 'min': 5, 'max': 120}),
            'employee_mood': forms.Select(attrs={'class': 'form-input'}),
            'topics_discussed': forms.Textarea(attrs={'class': 'form-input', 'rows': 4, 'placeholder': '話した内容を記録'}),
            'goal_progress_notes': forms.Textarea(attrs={'class': 'form-input', 'rows': 3, 'placeholder': '目標の進捗に関するメモ'}),
            'action_items': forms.Textarea(attrs={'class': 'form-input', 'rows': 2, 'placeholder': '次回までのアクションアイテム'}),
            'support_needed': forms.Textarea(attrs={'class': 'form-input', 'rows': 2, 'placeholder': '必要なサポート・リソース'}),
            'private_note': forms.Textarea(attrs={'class': 'form-input', 'rows': 2, 'placeholder': '管理者メモ（本人には非公開）'}),
        }

    def __init__(self, *args, company=None, **kwargs):
        super().__init__(*args, **kwargs)
        if company:
            self.fields['employee'].queryset = Employee.objects.filter(
                company=company, is_active=True
            ).order_by('last_name')
