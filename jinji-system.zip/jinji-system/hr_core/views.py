from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from companies.models import Company, Department
from .models import (
    Employee, Position, WageTable, EvaluationPeriod, Evaluation,
    Goal, GoalProgress, OneOnOneRecord, JobCategory,
    RaisePromotionRule, RaisePromotionProposal, PromotionRecord,
    SalaryIncreaseSystem, AllowanceType, EmployeeAllowance,
    JobDescription, CompetencyMaster, CompetencyLevelDef,
)
from .forms import GoalForm, GoalEditForm, GoalProgressForm, OneOnOneForm


def dashboard(request):
    """ダッシュボード"""
    companies = Company.objects.all()
    if companies.count() == 1:
        company = companies.first()
        stats = {
            'employee_count': Employee.objects.filter(company=company, is_active=True).count(),
            'department_count': Department.objects.filter(company=company, is_active=True).count(),
            'position_count': Position.objects.filter(company=company).count(),
            'active_evaluations': Evaluation.objects.filter(
                employee__company=company, status='draft'
            ).count(),
            'active_goals': Goal.objects.filter(
                employee__company=company, status='active'
            ).count(),
            'one_on_one_this_month': OneOnOneRecord.objects.filter(
                employee__company=company,
                meeting_date__month=__import__('datetime').date.today().month,
                meeting_date__year=__import__('datetime').date.today().year,
            ).count(),
        }
        recent_employees = Employee.objects.filter(
            company=company, is_active=True
        ).order_by('-hire_date')[:5]
        return render(request, 'hr_core/dashboard.html', {
            'company': company, 'companies': companies,
            'stats': stats, 'recent_employees': recent_employees,
        })
    return render(request, 'hr_core/dashboard.html', {'companies': companies})


def employee_list(request, company_id):
    company = get_object_or_404(Company, id=company_id)
    employees = Employee.objects.filter(company=company, is_active=True).select_related(
        'department', 'current_position'
    )
    dept_filter = request.GET.get('dept')
    if dept_filter:
        employees = employees.filter(department_id=dept_filter)
    departments = Department.objects.filter(company=company, is_active=True)
    return render(request, 'hr_core/employee_list.html', {
        'company': company, 'employees': employees, 'departments': departments,
        'current_dept': dept_filter,
    })


def employee_detail(request, pk):
    employee = get_object_or_404(Employee, pk=pk)
    evaluations = employee.evaluations.order_by('-period__start_date')[:5]
    goals = employee.goals.order_by('-period__start_date')[:10]
    promotions = employee.promotions.order_by('-effective_date')[:5]
    one_on_ones = employee.one_on_one_records.order_by('-meeting_date')[:5]
    return render(request, 'hr_core/employee_detail.html', {
        'employee': employee, 'evaluations': evaluations,
        'goals': goals, 'promotions': promotions,
        'one_on_ones': one_on_ones,
    })


def wage_table_list(request, company_id):
    company = get_object_or_404(Company, id=company_id)
    positions = Position.objects.filter(company=company).select_related(
        'job_category', 'wage_table'
    ).order_by('job_category', 'grade')
    salary_system = SalaryIncreaseSystem.objects.filter(company=company).first()

    # 会社全体の給与統計
    from django.db.models import Avg, Sum, Min, Max
    employees = Employee.objects.filter(company=company, is_active=True)
    salary_stats = employees.aggregate(
        avg_base=Avg('current_base_salary'),
        min_base=Min('current_base_salary'),
        max_base=Max('current_base_salary'),
        total_base=Sum('current_base_salary'),
    )

    return render(request, 'hr_core/wage_table_list.html', {
        'company': company, 'positions': positions,
        'salary_system': salary_system, 'salary_stats': salary_stats,
        'employee_count': employees.count(),
    })


def wage_step_matrix(request, company_id):
    """号俸表マトリクス（等級×号俸の全展開）"""
    company = get_object_or_404(Company, id=company_id)
    positions = Position.objects.filter(company=company).select_related(
        'job_category', 'wage_table'
    ).order_by('job_category', 'grade')

    # 職種フィルター
    job_cat_id = request.GET.get('job_cat')
    job_categories = JobCategory.objects.filter(company=company)
    if job_cat_id:
        positions = positions.filter(job_category_id=job_cat_id)

    # マトリクスデータを構築
    matrix_data = []
    max_step = 0
    for pos in positions:
        if hasattr(pos, 'wage_table'):
            wt = pos.wage_table
            max_step = max(max_step, wt.max_steps)
            row = {
                'position': pos,
                'wage_table': wt,
                'steps': wt.get_full_table(),
            }
            # この等級に在籍する社員数
            row['employee_count'] = Employee.objects.filter(
                company=company, current_position=pos, is_active=True
            ).count()
            matrix_data.append(row)

    # CSV出力
    if request.GET.get('export') == 'csv':
        import csv
        from django.http import HttpResponse
        response = HttpResponse(content_type='text/csv; charset=utf-8-sig')
        response['Content-Disposition'] = 'attachment; filename="wage_table.csv"'
        writer = csv.writer(response)
        header = ['職種', '職位', '等級']
        header += [f'{s}号' for s in range(1, max_step + 1)]
        writer.writerow(header)
        for row in matrix_data:
            line = [
                row['position'].job_category.name,
                row['position'].name,
                row['position'].grade,
            ]
            line += [s['salary'] for s in row['steps']]
            # パディング
            line += [''] * (max_step - len(row['steps']))
            writer.writerow(line)
        return response

    return render(request, 'hr_core/wage_step_matrix.html', {
        'company': company, 'matrix_data': matrix_data,
        'max_step': max_step,
        'step_range': range(1, max_step + 1),
        'job_categories': job_categories,
        'current_job_cat': job_cat_id,
    })


def allowance_list(request, company_id):
    """手当種別一覧＆社員別手当管理"""
    company = get_object_or_404(Company, id=company_id)
    allowance_types = AllowanceType.objects.filter(company=company, is_active=True)

    # デフォルト手当を自動生成
    if not allowance_types.exists() and request.method == 'POST' and 'generate_defaults' in request.POST:
        defaults = [
            ('position', '役職手当', 'fixed', 0, '役職に応じて支給', 1),
            ('family', '家族手当（配偶者）', 'fixed', 15000, '配偶者を扶養する場合に支給', 2),
            ('family', '家族手当（子）', 'fixed', 5000, '子1人あたり（18歳未満）', 3),
            ('housing', '住宅手当', 'tier', 0, '世帯主に支給。持家:10,000円、賃貸:20,000円', 4),
            ('commute', '通勤手当', 'actual', 0, '公共交通機関の定期代を実費支給（上限50,000円）', 5),
            ('qualification', '資格手当', 'fixed', 0, '業務関連資格の保有者に支給', 6),
            ('skill', '技能手当', 'fixed', 0, '特定技能・専門スキル保有者に支給', 7),
            ('overtime_fixed', '固定残業手当', 'fixed', 0, '月20時間分の固定残業代', 8),
            ('region', '地域手当', 'percentage', 0, '勤務地に応じた生活費補助', 9),
        ]
        for cat, name, calc, amount, desc, order in defaults:
            at = AllowanceType.objects.create(
                company=company, category=cat, name=name,
                calc_method=calc, default_amount=amount,
                description=desc, sort_order=order,
            )
            if cat == 'commute':
                at.max_amount = 50000
                at.taxable = False
                at.save()
            if cat == 'housing':
                at.tier_rules = '[{"label":"持家","amount":10000},{"label":"賃貸","amount":20000}]'
                at.save()
        messages.success(request, 'デフォルトの手当種別を生成しました。')
        return redirect('allowance_list', company_id=company.id)

    # 社員別手当の集計
    employees = Employee.objects.filter(
        company=company, is_active=True
    ).prefetch_related('allowances', 'allowances__allowance_type').select_related(
        'department', 'current_position'
    ).order_by('department__name', 'last_name')

    emp_allowance_data = []
    for emp in employees:
        active_allowances = [a for a in emp.allowances.all() if a.is_current]
        total = sum(a.amount for a in active_allowances)
        emp_allowance_data.append({
            'employee': emp,
            'allowances': active_allowances,
            'total_allowances': total,
            'total_salary': emp.current_base_salary + total,
        })

    return render(request, 'hr_core/allowance_list.html', {
        'company': company, 'allowance_types': allowance_types,
        'emp_allowance_data': emp_allowance_data,
    })


def salary_simulation(request, company_id):
    """賃金シミュレーション"""
    company = get_object_or_404(Company, id=company_id)
    employees = Employee.objects.filter(
        company=company, is_active=True
    ).select_related('current_position', 'department').prefetch_related(
        'allowances', 'allowances__allowance_type'
    )
    positions = Position.objects.filter(company=company).select_related(
        'job_category', 'wage_table'
    ).order_by('job_category', 'grade')
    salary_system = SalaryIncreaseSystem.objects.filter(company=company).first()

    result = None
    if request.method == 'POST':
        emp_id = request.POST.get('employee')
        sim_type = request.POST.get('sim_type')

        emp = get_object_or_404(Employee, pk=emp_id)
        active_allowances = [a for a in emp.allowances.all() if a.is_current]
        current_allowance_total = sum(a.amount for a in active_allowances)

        result = {
            'employee': emp,
            'sim_type': sim_type,
            'current_base': emp.current_base_salary,
            'current_allowances': current_allowance_total,
            'current_total': emp.current_base_salary + current_allowance_total,
            'allowance_details': active_allowances,
        }

        if sim_type == 'raise':
            # 昇給シミュレーション
            steps = int(request.POST.get('raise_steps', 1))
            step_amount = salary_system.increase_amount_per_step if salary_system else 1000
            raise_amount = steps * step_amount
            new_base = emp.current_base_salary + raise_amount
            result.update({
                'raise_steps': steps,
                'step_amount': step_amount,
                'raise_amount': raise_amount,
                'new_base': new_base,
                'new_total': new_base + current_allowance_total,
                'annual_impact': raise_amount * 12,
            })

        elif sim_type == 'promotion':
            # 昇格シミュレーション
            to_pos_id = request.POST.get('to_position')
            to_pos = get_object_or_404(Position, pk=to_pos_id)
            new_base = emp.current_base_salary
            new_allowance_total = current_allowance_total

            if hasattr(to_pos, 'wage_table'):
                wt = to_pos.wage_table
                # 昇格先の初号給が現在の基本給より高い場合、初号給を適用
                if wt.base_salary_start > emp.current_base_salary:
                    new_base = wt.base_salary_start
                # 役職手当の差額
                old_pos_allowance = 0
                new_pos_allowance = wt.position_allowance
                if emp.current_position and hasattr(emp.current_position, 'wage_table'):
                    old_pos_allowance = emp.current_position.wage_table.position_allowance
                allowance_diff = new_pos_allowance - old_pos_allowance
                new_allowance_total = current_allowance_total + allowance_diff
            else:
                allowance_diff = 0

            result.update({
                'to_position': to_pos,
                'new_base': new_base,
                'base_diff': new_base - emp.current_base_salary,
                'allowance_diff': allowance_diff if hasattr(to_pos, 'wage_table') else 0,
                'new_allowance_total': new_allowance_total,
                'new_total': new_base + new_allowance_total,
                'annual_impact': (new_base + new_allowance_total - emp.current_base_salary - current_allowance_total) * 12,
            })

        elif sim_type == 'both':
            # 昇給＋昇格の同時シミュレーション
            steps = int(request.POST.get('raise_steps', 1))
            to_pos_id = request.POST.get('to_position')
            to_pos = get_object_or_404(Position, pk=to_pos_id)
            step_amount = salary_system.increase_amount_per_step if salary_system else 1000
            raise_amount = steps * step_amount
            new_base = emp.current_base_salary + raise_amount
            new_allowance_total = current_allowance_total

            if hasattr(to_pos, 'wage_table'):
                wt = to_pos.wage_table
                if wt.base_salary_start > new_base:
                    new_base = wt.base_salary_start
                old_pos_allowance = 0
                new_pos_allowance = wt.position_allowance
                if emp.current_position and hasattr(emp.current_position, 'wage_table'):
                    old_pos_allowance = emp.current_position.wage_table.position_allowance
                allowance_diff = new_pos_allowance - old_pos_allowance
                new_allowance_total = current_allowance_total + allowance_diff
            else:
                allowance_diff = 0

            result.update({
                'raise_steps': steps,
                'raise_amount': raise_amount,
                'to_position': to_pos,
                'new_base': new_base,
                'allowance_diff': allowance_diff if hasattr(to_pos, 'wage_table') else 0,
                'new_allowance_total': new_allowance_total,
                'new_total': new_base + new_allowance_total,
                'annual_impact': (new_base + new_allowance_total - emp.current_base_salary - current_allowance_total) * 12,
            })

    return render(request, 'hr_core/salary_simulation.html', {
        'company': company, 'employees': employees,
        'positions': positions, 'salary_system': salary_system,
        'result': result,
    })


def evaluation_list(request, company_id):
    company = get_object_or_404(Company, id=company_id)
    periods = EvaluationPeriod.objects.filter(company=company)
    period_id = request.GET.get('period')
    evaluations = Evaluation.objects.filter(employee__company=company).select_related(
        'employee', 'period'
    )
    if period_id:
        evaluations = evaluations.filter(period_id=period_id)
    return render(request, 'hr_core/evaluation_list.html', {
        'company': company, 'periods': periods,
        'evaluations': evaluations, 'current_period': period_id,
    })


def evaluation_detail(request, pk):
    evaluation = get_object_or_404(Evaluation, pk=pk)
    scores = evaluation.scores.select_related('criteria').order_by('criteria__sort_order')
    return render(request, 'hr_core/evaluation_detail.html', {
        'evaluation': evaluation, 'scores': scores,
    })


def goal_list(request, company_id):
    company = get_object_or_404(Company, id=company_id)
    goals = Goal.objects.filter(employee__company=company).select_related(
        'employee', 'period'
    ).prefetch_related('progress_logs').order_by('-period__start_date', 'employee')

    # フィルター
    category_filter = request.GET.get('category')
    status_filter = request.GET.get('status')
    if category_filter:
        goals = goals.filter(category=category_filter)
    if status_filter:
        goals = goals.filter(status=status_filter)

    # 集計
    from django.db.models import Avg, Count, Q
    active_goals = Goal.objects.filter(employee__company=company, status='active')
    summary = {
        'total': goals.count(),
        'active': active_goals.count(),
        'avg_achievement': active_goals.aggregate(avg=Avg('achievement_rate'))['avg'] or 0,
        'on_track': GoalProgress.objects.filter(
            goal__employee__company=company,
            goal__status='active',
            progress_status='on_track'
        ).values('goal').distinct().count(),
        'at_risk': GoalProgress.objects.filter(
            goal__employee__company=company,
            goal__status='active',
            progress_status__in=['at_risk', 'behind']
        ).values('goal').distinct().count(),
        'by_category': {
            'performance': active_goals.filter(category='performance').count(),
            'competency': active_goals.filter(category='competency').count(),
            'behavior': active_goals.filter(category='behavior').count(),
        },
    }

    return render(request, 'hr_core/goal_list.html', {
        'company': company, 'goals': goals, 'summary': summary,
        'current_category': category_filter, 'current_status': status_filter,
    })


def goal_detail(request, pk):
    goal = get_object_or_404(Goal, pk=pk)
    progress_logs = goal.progress_logs.order_by('-recorded_date')
    child_goals = goal.child_goals.select_related('employee')
    return render(request, 'hr_core/goal_detail.html', {
        'goal': goal, 'progress_logs': progress_logs,
        'child_goals': child_goals,
        'company': goal.employee.company,
    })


def goal_create(request, company_id):
    """目標の新規作成"""
    company = get_object_or_404(Company, id=company_id)
    if request.method == 'POST':
        form = GoalForm(request.POST, company=company)
        if form.is_valid():
            goal = form.save()
            messages.success(request, f'目標「{goal.title}」を作成しました。')
            return redirect('goal_detail', pk=goal.pk)
    else:
        form = GoalForm(company=company)
    return render(request, 'hr_core/goal_form.html', {
        'company': company, 'form': form, 'is_edit': False,
    })


def goal_edit(request, pk):
    """目標の実績・振り返り更新"""
    goal = get_object_or_404(Goal, pk=pk)
    company = goal.employee.company
    if request.method == 'POST':
        form = GoalEditForm(request.POST, instance=goal)
        if form.is_valid():
            form.save()
            messages.success(request, f'目標「{goal.title}」を更新しました。')
            return redirect('goal_detail', pk=goal.pk)
    else:
        form = GoalEditForm(instance=goal)
    return render(request, 'hr_core/goal_edit_form.html', {
        'company': company, 'form': form, 'goal': goal,
    })


def goal_progress_create(request, goal_id):
    """進捗チェックインの登録"""
    goal = get_object_or_404(Goal, pk=goal_id)
    company = goal.employee.company
    if request.method == 'POST':
        form = GoalProgressForm(request.POST)
        if form.is_valid():
            progress = form.save(commit=False)
            progress.goal = goal
            progress.save()
            # 目標の達成率も自動更新
            goal.achievement_rate = progress.progress_rate
            goal.save(update_fields=['achievement_rate'])
            messages.success(request, f'進捗を記録しました（{progress.progress_rate}%）。')
            return redirect('goal_detail', pk=goal.pk)
    else:
        from datetime import date
        form = GoalProgressForm(initial={
            'recorded_date': date.today(),
            'progress_rate': goal.achievement_rate,
        })
    return render(request, 'hr_core/goal_progress_form.html', {
        'company': company, 'form': form, 'goal': goal,
    })


def one_on_one_create(request, company_id):
    """1on1面談の新規登録"""
    company = get_object_or_404(Company, id=company_id)
    if request.method == 'POST':
        form = OneOnOneForm(request.POST, company=company)
        if form.is_valid():
            record = form.save()
            messages.success(request, f'{record.employee.full_name}の1on1面談を記録しました。')
            return redirect('one_on_one_list', company_id=company.id)
    else:
        from datetime import date
        form = OneOnOneForm(company=company, initial={
            'meeting_date': date.today(),
            'duration_minutes': 30,
        })
    return render(request, 'hr_core/one_on_one_form.html', {
        'company': company, 'form': form,
    })


def one_on_one_list(request, company_id):
    company = get_object_or_404(Company, id=company_id)
    records = OneOnOneRecord.objects.filter(
        employee__company=company
    ).select_related('employee').order_by('-meeting_date')

    emp_filter = request.GET.get('emp')
    if emp_filter:
        records = records.filter(employee_id=emp_filter)

    employees = Employee.objects.filter(company=company, is_active=True).order_by('last_name')

    from django.db.models import Count, Avg
    mood_summary = records.values('employee_mood').annotate(count=Count('id'))
    mood_dict = {m['employee_mood']: m['count'] for m in mood_summary}

    return render(request, 'hr_core/one_on_one_list.html', {
        'company': company, 'records': records,
        'employees': employees, 'current_emp': emp_filter,
        'mood_dict': mood_dict,
    })


def goal_progress_dashboard(request, company_id):
    company = get_object_or_404(Company, id=company_id)
    from django.db.models import Avg, Count, Q

    # アクティブ期間の目標
    active_period = EvaluationPeriod.objects.filter(company=company, is_active=True).first()
    goals = Goal.objects.filter(
        employee__company=company
    ).select_related('employee', 'period').prefetch_related('progress_logs')

    if active_period:
        goals = goals.filter(period=active_period)

    # 社員別の目標サマリー
    employees = Employee.objects.filter(
        company=company, is_active=True
    ).prefetch_related('goals', 'one_on_one_records')

    employee_summaries = []
    for emp in employees:
        emp_goals = goals.filter(employee=emp)
        if emp_goals.exists():
            avg_rate = emp_goals.aggregate(avg=Avg('achievement_rate'))['avg'] or 0
            latest_1on1 = emp.one_on_one_records.order_by('-meeting_date').first()
            employee_summaries.append({
                'employee': emp,
                'goal_count': emp_goals.count(),
                'avg_achievement': round(avg_rate),
                'completed': emp_goals.filter(status='completed').count(),
                'at_risk': emp_goals.filter(
                    progress_logs__progress_status__in=['at_risk', 'behind']
                ).distinct().count(),
                'latest_1on1': latest_1on1,
            })

    employee_summaries.sort(key=lambda x: x['avg_achievement'])

    return render(request, 'hr_core/goal_progress_dashboard.html', {
        'company': company, 'active_period': active_period,
        'employee_summaries': employee_summaries,
    })


# ================================================================
# 等級制度・職務記述・コンピテンシー
# ================================================================

def grade_framework(request, company_id):
    """等級制度フレームワーク一覧"""
    company = get_object_or_404(Company, id=company_id)
    job_categories = JobCategory.objects.filter(company=company)

    # 職種フィルター
    job_cat_id = request.GET.get('job_cat')
    positions = Position.objects.filter(company=company).select_related(
        'job_category'
    ).order_by('job_category', 'grade')
    if job_cat_id:
        positions = positions.filter(job_category_id=job_cat_id)

    return render(request, 'hr_core/grade_framework.html', {
        'company': company, 'positions': positions,
        'job_categories': job_categories, 'current_job_cat': job_cat_id,
    })


def grade_detail(request, pk):
    """等級詳細（等級定義 + 職務記述 + コンピテンシーレベル）"""
    position = get_object_or_404(Position, pk=pk)
    company = position.company

    # 職務記述書
    jd = getattr(position, 'jd', None)

    # コンピテンシーレベル定義
    comp_levels = CompetencyLevelDef.objects.filter(
        position=position
    ).select_related('competency').order_by('competency__category', 'competency__sort_order')

    # 同じ職種の前後等級
    same_cat = Position.objects.filter(
        company=company, job_category=position.job_category
    ).order_by('grade')
    prev_grade = same_cat.filter(grade__lt=position.grade).last()
    next_grade = same_cat.filter(grade__gt=position.grade).first()

    # この等級の在籍者
    employees = Employee.objects.filter(
        company=company, current_position=position, is_active=True
    )

    return render(request, 'hr_core/grade_detail.html', {
        'company': company, 'position': position,
        'jd': jd, 'comp_levels': comp_levels,
        'prev_grade': prev_grade, 'next_grade': next_grade,
        'employees': employees,
    })


def competency_list(request, company_id):
    """コンピテンシーモデル一覧"""
    company = get_object_or_404(Company, id=company_id)
    competencies = CompetencyMaster.objects.filter(company=company, is_active=True)

    # デフォルト生成
    if not competencies.exists() and request.method == 'POST' and 'generate_defaults' in request.POST:
        defaults = [
            ('core', '課題解決力', '問題を正確に把握し、論理的に分析して解決策を導く力', 1),
            ('core', 'コミュニケーション', '相手の立場を理解し、自分の考えを分かりやすく伝える力', 2),
            ('core', '主体性・当事者意識', '自ら考え行動し、責任を持って業務を遂行する姿勢', 3),
            ('core', 'チームワーク', '他者と協力し、チーム全体の成果に貢献する力', 4),
            ('core', '成長意欲', '自己の成長に向けて積極的に学び、挑戦する姿勢', 5),
            ('management', 'リーダーシップ', 'ビジョンを示し、メンバーを動機づけ、組織を導く力', 6),
            ('management', '人材育成', '部下・後輩の成長を支援し、組織の人材力を高める力', 7),
            ('management', '戦略思考', '中長期的な視点で組織の方向性を構想し、実行計画を策定する力', 8),
            ('management', '組織マネジメント', '組織の目標達成に向けて、リソースを最適配分する力', 9),
            ('functional', '専門知識・技術', '担当領域における専門的な知識と技術を保有・活用する力', 10),
            ('functional', '業務改善', '現状のプロセスを分析し、効率化・品質向上を実現する力', 11),
            ('functional', '顧客志向', '顧客のニーズを理解し、期待を超える価値を提供する姿勢', 12),
        ]
        for cat, name, defn, order in defaults:
            CompetencyMaster.objects.create(
                company=company, category=cat, name=name,
                definition=defn, sort_order=order,
            )
        messages.success(request, 'デフォルトのコンピテンシー項目を生成しました。')
        return redirect('competency_list', company_id=company.id)

    # 等級別レベルマトリクス
    positions = Position.objects.filter(company=company).order_by('job_category', 'grade')
    matrix = []
    for comp in competencies:
        levels = {}
        for lvl in comp.level_defs.select_related('position'):
            levels[lvl.position_id] = lvl
        matrix.append({'competency': comp, 'levels': levels})

    return render(request, 'hr_core/competency_list.html', {
        'company': company, 'competencies': competencies,
        'positions': positions, 'matrix': matrix,
    })


def competency_setup(request, company_id):
    """コンピテンシーレベルの一括設定"""
    company = get_object_or_404(Company, id=company_id)
    competencies = CompetencyMaster.objects.filter(company=company, is_active=True)
    positions = Position.objects.filter(company=company).order_by('job_category', 'grade')

    if request.method == 'POST':
        created = 0
        updated = 0
        for comp in competencies:
            for pos in positions:
                key = f'level_{comp.pk}_{pos.pk}'
                bkey = f'behavior_{comp.pk}_{pos.pk}'
                level_val = request.POST.get(key)
                behavior_val = request.POST.get(bkey, '')
                if level_val:
                    obj, was_created = CompetencyLevelDef.objects.update_or_create(
                        competency=comp, position=pos,
                        defaults={
                            'expected_level': int(level_val),
                            'expected_behaviors': behavior_val,
                        }
                    )
                    if was_created:
                        created += 1
                    else:
                        updated += 1
        messages.success(request, f'コンピテンシーレベルを保存しました（新規{created}件、更新{updated}件）。')
        return redirect('competency_list', company_id=company.id)

    # 現在の設定を取得
    existing = {}
    for lvl in CompetencyLevelDef.objects.filter(
        competency__company=company
    ).select_related('competency', 'position'):
        existing[(lvl.competency_id, lvl.position_id)] = lvl

    return render(request, 'hr_core/competency_setup.html', {
        'company': company, 'competencies': competencies,
        'positions': positions, 'existing': existing,
    })


def org_chart(request, company_id):
    company = get_object_or_404(Company, id=company_id)
    departments = Department.objects.filter(
        company=company, is_active=True
    ).prefetch_related('employees')
    return render(request, 'hr_core/org_chart.html', {
        'company': company, 'departments': departments,
    })


# ================================================================
# 昇給・昇格連動
# ================================================================

def raise_promotion_rules(request, company_id):
    """昇給・昇格ルール一覧＆設定"""
    company = get_object_or_404(Company, id=company_id)
    rules = RaisePromotionRule.objects.filter(company=company)

    # ルールが未設定の場合、デフォルトを自動生成
    if not rules.exists() and request.method == 'POST' and 'generate_defaults' in request.POST:
        defaults = [
            ('S', 4.5, 5.0, 4, True, 1.5, '卓越した成果。昇格候補。'),
            ('A', 3.5, 4.4, 3, True, 1.2, '優秀な成果。昇格検討対象。'),
            ('B', 2.5, 3.4, 2, False, 1.0, '標準的な成果。通常昇給。'),
            ('C', 1.5, 2.4, 1, False, 0.8, '改善が必要。昇給抑制。'),
            ('D', 0.0, 1.4, 0, False, 0.5, '大幅な改善が必要。昇給なし。'),
        ]
        for rank, smin, smax, steps, promo, bonus, desc in defaults:
            RaisePromotionRule.objects.create(
                company=company, eval_rank=rank,
                score_min=smin, score_max=smax,
                raise_steps=steps, promotion_eligible=promo,
                bonus_multiplier=bonus, description=desc,
            )
        messages.success(request, 'デフォルトの昇給・昇格ルールを生成しました。')
        return redirect('raise_promotion_rules', company_id=company.id)

    salary_system = SalaryIncreaseSystem.objects.filter(company=company).first()
    return render(request, 'hr_core/raise_promotion_rules.html', {
        'company': company, 'rules': rules, 'salary_system': salary_system,
    })


def generate_proposals(request, company_id):
    """確定済み評価から昇給・昇格提案を一括生成"""
    company = get_object_or_404(Company, id=company_id)

    if request.method != 'POST':
        # GET: 対象期間を選択する画面
        periods = EvaluationPeriod.objects.filter(company=company)
        return render(request, 'hr_core/generate_proposals.html', {
            'company': company, 'periods': periods,
        })

    # POST: 提案を生成
    period_id = request.POST.get('period')
    period = get_object_or_404(EvaluationPeriod, pk=period_id)
    rules = RaisePromotionRule.objects.filter(company=company)

    if not rules.exists():
        messages.error(request, '昇給・昇格ルールが未設定です。先にルールを設定してください。')
        return redirect('raise_promotion_rules', company_id=company.id)

    evaluations = Evaluation.objects.filter(
        period=period, status='approved',
        employee__company=company,
    ).select_related('employee', 'employee__current_position')

    created_count = 0
    skipped_count = 0
    salary_system = SalaryIncreaseSystem.objects.filter(company=company).first()
    step_amount = salary_system.increase_amount_per_step if salary_system else 1000

    for ev in evaluations:
        # 既に提案がある場合はスキップ
        if RaisePromotionProposal.objects.filter(employee=ev.employee, evaluation=ev).exists():
            skipped_count += 1
            continue

        # スコアに該当するルールを検索
        rule = rules.filter(
            score_min__lte=ev.overall_score,
            score_max__gte=ev.overall_score,
        ).first()

        if not rule:
            skipped_count += 1
            continue

        current_salary = ev.employee.current_base_salary
        raise_amount = rule.raise_steps * step_amount
        new_salary = current_salary + raise_amount

        # 昇格先の自動判定（同じ職種の1つ上のgradeを探す）
        proposed_position = None
        if rule.promotion_eligible and ev.employee.current_position:
            cp = ev.employee.current_position
            next_pos = Position.objects.filter(
                company=company,
                job_category=cp.job_category,
                grade=cp.grade + 1,
            ).first()
            proposed_position = next_pos

        RaisePromotionProposal.objects.create(
            employee=ev.employee,
            evaluation=ev,
            rule=rule,
            eval_rank=rule.eval_rank,
            current_salary=current_salary,
            raise_steps=rule.raise_steps,
            raise_amount=raise_amount,
            new_salary=new_salary,
            is_promotion_candidate=rule.promotion_eligible,
            current_position=ev.employee.current_position,
            proposed_position=proposed_position,
            bonus_multiplier=rule.bonus_multiplier,
        )
        created_count += 1

    messages.success(request, f'{created_count}件の提案を生成しました（スキップ: {skipped_count}件）。')
    return redirect('proposal_list', company_id=company.id)


def proposal_list(request, company_id):
    """昇給・昇格提案の一覧"""
    company = get_object_or_404(Company, id=company_id)
    proposals = RaisePromotionProposal.objects.filter(
        employee__company=company
    ).select_related(
        'employee', 'evaluation', 'evaluation__period',
        'current_position', 'proposed_position', 'rule',
    ).order_by('-created_at')

    status_filter = request.GET.get('status')
    if status_filter:
        proposals = proposals.filter(status=status_filter)

    from django.db.models import Sum, Count
    summary = {
        'total': proposals.count(),
        'pending': proposals.filter(status='pending').count(),
        'approved': proposals.filter(status='approved').count(),
        'applied': proposals.filter(status='applied').count(),
        'total_raise': proposals.filter(
            status__in=['approved', 'applied']
        ).aggregate(s=Sum('raise_amount'))['s'] or 0,
        'promotion_count': proposals.filter(
            is_promotion_candidate=True,
            status__in=['approved', 'applied'],
        ).count(),
    }

    return render(request, 'hr_core/proposal_list.html', {
        'company': company, 'proposals': proposals,
        'summary': summary, 'current_status': status_filter,
    })


def proposal_approve(request, pk):
    """提案の承認・却下・適用"""
    proposal = get_object_or_404(RaisePromotionProposal, pk=pk)
    company = proposal.employee.company

    if request.method == 'POST':
        action = request.POST.get('action')
        approved_by = request.POST.get('approved_by', '')
        effective_date = request.POST.get('effective_date')
        notes = request.POST.get('notes', '')

        from datetime import date, datetime

        if action == 'approve':
            proposal.status = 'approved'
            proposal.approved_by = approved_by
            proposal.approved_at = datetime.now()
            proposal.effective_date = effective_date or date.today()
            proposal.notes = notes
            proposal.save()
            messages.success(request, f'{proposal.employee.full_name}の昇給・昇格提案を承認しました。')

        elif action == 'reject':
            proposal.status = 'rejected'
            proposal.approved_by = approved_by
            proposal.notes = notes
            proposal.save()
            messages.info(request, f'{proposal.employee.full_name}の提案を却下しました。')

        elif action == 'apply':
            if proposal.status != 'approved':
                messages.error(request, '承認済みの提案のみ適用できます。')
            else:
                if not proposal.effective_date:
                    proposal.effective_date = date.today()
                proposal.apply_to_employee()
                messages.success(request, f'{proposal.employee.full_name}に昇給・昇格を適用しました。')

        return redirect('proposal_list', company_id=company.id)

    return render(request, 'hr_core/proposal_approve.html', {
        'company': company, 'proposal': proposal,
    })
